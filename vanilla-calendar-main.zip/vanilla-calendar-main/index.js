import VanillaCalendar from './src/vanilla-calendar.js';
import './src/vanilla-calendar.scss';

export default VanillaCalendar;
